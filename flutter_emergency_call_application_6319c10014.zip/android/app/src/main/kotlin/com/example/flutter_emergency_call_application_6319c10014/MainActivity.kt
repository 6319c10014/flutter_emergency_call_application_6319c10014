package com.example.flutter_emergency_call_application_6319c10014

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
