class PhoneEmerList {
  String? name;
  String? mobile;
  String? image;
  String? detail;

  PhoneEmerList({
    this.name,
    this.mobile,
    this.image,
    this.detail,
  });
}
